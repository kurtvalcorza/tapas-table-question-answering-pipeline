"""TPQ review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import json, os, sys, types, re, importlib
from pathlib import Path

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/tapas_table_qa_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
P = importlib.import_module('tapas_table_qa_pipeline.pipeline'); S = importlib.import_module('tapas_table_qa_pipeline.samples'); M = importlib.import_module('tapas_table_qa_pipeline.metrics')
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
pipe_src = (repo / 'src/tapas_table_qa_pipeline/pipeline.py').read_text()
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell_pip_in_kernel': "'-m', 'pip', 'install'" in src(3), 'restart_guard_text': 'Restart the runtime, then rerun from the top.' in src(3),
    'asserts': [(i, l.strip()) for i in code if i not in (5, 7, 9) for l in src(i).splitlines() if l.strip().startswith('assert ')],
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'adapt_initial_state_from_live_model': 'frozen_state = {k: v.detach().clone() for k, v in model.state_dict().items() if k in name_set}' in pipe_src,
    'epoch0_note_frozen_model': '"note": "frozen model"' in pipe_src}

# P2 prose claims vs the recorded Kaggle T4 run of this blob
rec = {'accuracy': [0.82, 0.813], 'aggregation_accuracy': [0.567, 0.807], 'cell_accuracy': [0.82, 0.833],
       'by_category_accuracy': {'average': [0.88, 0.92], 'count': [0.64, 0.64], 'lookup': [0.92, 0.88], 'max': [0.8, 0.76], 'min': [0.84, 0.84], 'sum': [0.84, 0.84]},
       'by_category_aggregation': {'average': [0.76, 0.76], 'count': [0.72, 0.64], 'lookup': [0.76, 1.0], 'max': [0.12, 0.92], 'min': [0.16, 0.96], 'sum': [0.88, 0.56]}}
claims = {
    'cell20: denotation 0.82 -> 0.84 (three questions of 150)': '0.82 → 0.84' in src(20),
    'cell20: average, min and sum each gained one question': '`average`, `min` and `sum` each gained one question' in src(20),
    'cell20: lookups stayed at 0.92': 'lookups stayed at 0.92' in src(20),
    'cell20: the GPU run gained three questions': 'the GPU run gained three questions' in src(20),
    'cell24: with the lookups untouched': 'with the lookups untouched' in src(24),
    'cell24: cell selection 0.82 -> 0.85': '(0.82 → 0.85)' in src(24)}
R['P2_prose_vs_record'] = {'claims_present_in_prose': claims, 'recorded_kaggle_T4_blob_6ed641ea': rec,
    'per_category_questions_changed_in_record': {c: round((v[1] - v[0]) * 25) for c, v in rec['by_category_accuracy'].items()},
    'sum_aggregation_questions_changed_in_record': round((0.56 - 0.88) * 25)}

# P3 the pipeline arithmetic and the denotation match on the notebook's own city table and edge cells
city = ['1,846,513', '964,169', '1,776,949', '366,358']
R['P3_arithmetic'] = {
    'parse_number': {c: P.parse_number(c) for c in ['1,846,513', '3.5%', '-12', '−12', '$12', '(12)', '1 234', '12 km', '1.2e3']},
    'sum_manila_davao': P.compute_numeric_answer([city[0], city[2]], 'SUM'), 'city_sum_gold': 3623462,
    'denotation_match_sum': P.denotation_match({'cells': [city[0], city[2]], 'aggregation': 'SUM', 'numeric_answer': 3623462.0}, 3623462),
    'denotation_match_count_gold_4': P.denotation_match({'cells': ['Manila', 'Cebu', 'Davao', 'Baguio'], 'aggregation': 'COUNT', 'numeric_answer': 4.0}, 4),
    'denotation_match_lookup_case': P.denotation_match({'cells': ['cebu '], 'aggregation': 'NONE', 'numeric_answer': None}, 'Cebu'),
    'denotation_match_lookup_number_cell_vs_string_gold': P.denotation_match({'cells': ['1,846,513'], 'aggregation': 'NONE', 'numeric_answer': None}, '1846513'),
}

# P4 BYOD JSONL through cell 13's sequence
def rec_(i, t, agg='NONE'):
    table = {'Name': [f'n{t}-{k}' for k in range(4)], 'Value': [str(10 * k + t) for k in range(4)]}
    if agg == 'NONE': ans = {'aggregation': 'NONE', 'coordinates': [[1, 0]], 'denotation': [f'n{t}-1']}
    else: ans = {'aggregation': 'SUM', 'coordinates': [[0, 1], [1, 1]], 'denotation': float(t + 10 + t)}
    return {'id': f'q{i}', 'table': table, 'question': f'question {i} about table {t}?', 'answer': ans}
def write(name, records, raw=None):
    p = out / name; p.write_text(raw if raw is not None else '\n'.join(json.dumps(r) for r in records)); return p
def nb_byod(p):
    recs = S.load_byod_dataset(p); sp = S.split_dataset(recs, seed=42)
    m = {k: S.validate_dataset(v) for k, v in sp.items()}; S.check_split_disjoint(sp)
    return {k: x['n_records'] for k, x in m.items()}
def run(name, fn):
    try: return {'case': name, 'verdict': 'accepted', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'refused', 'error': f'{type(e).__name__}: {e}'[:220]}
grid = {}
for n_tables in (2, 5, 10, 20):
    for per in (4, 8):
        recs = [rec_(t * per + k, t, 'SUM' if k % 2 else 'NONE') for t in range(n_tables) for k in range(per)]
        grid[f'{n_tables} tables x {per} questions = {n_tables * per}'] = run('g', lambda recs=recs: nb_byod(write('g.jsonl', recs)))['verdict']
base = [rec_(t * 8 + k, t, 'SUM' if k % 2 else 'NONE') for t in range(20) for k in range(8)]
bad_num = json.loads(json.dumps(base)); bad_num[0]['table']['Value'] = [10, 11, 12, 13]
bad_sum = json.loads(json.dumps(base)); bad_sum[1]['answer']['denotation'] = 999.0
bad_coord = json.loads(json.dumps(base)); bad_coord[0]['answer']['coordinates'] = [[9, 0]]
cases = [
    run('20 tables x 8 questions', lambda: nb_byod(write('a.jsonl', base))),
    run('JSON list instead of JSONL', lambda: nb_byod(write('b.jsonl', None, raw=json.dumps(base)))),
    run('numeric cells as JSON numbers', lambda: nb_byod(write('c.jsonl', bad_num))),
    run('SUM denotation that disagrees with its cells', lambda: nb_byod(write('d.jsonl', bad_sum))),
    run('coordinate outside the table', lambda: nb_byod(write('e.jsonl', bad_coord))),
    run('one malformed JSONL line', lambda: nb_byod(write('f.jsonl', None, raw='\n'.join(json.dumps(r) for r in base) + '\n{"id": "x", "table":'))),
    run('UTF-8 BOM', lambda: nb_byod((lambda p: (p.write_bytes(b'\xef\xbb\xbf' + '\n'.join(json.dumps(r) for r in base).encode()), p)[1])(out / 'bom.jsonl'))),
]
R['P4_byod'] = {'stated_minimum': 'at least eight questions over at least two tables', 'grid_tables_by_questions': grid, 'matrix': cases}
c13 = src(13).replace('USE_BYOD = False', 'USE_BYOD = True'); head = c13.split('    records = load_byod_dataset')[0]
def exec_upload(up, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm; cm.files = types.SimpleNamespace(upload=lambda: up)
        sys.modules['google'] = g; sys.modules['google.colab'] = cm
    cwd = os.getcwd(); os.chdir(out)
    try:
        ns = {'Path': Path, 'os': os}; exec(compile(head, 'cell13', 'exec'), ns); return ns.get('file_name')
    finally: os.chdir(cwd)
R['P5_upload'] = {'cancelled': run('cancelled', lambda: exec_upload({})), 'outside Colab': run('outside', lambda: exec_upload(None, colab=False)), 'has_path_field': bool(re.search(r'BYOD_(PATH|FILE)\s*=', src(13)))}
for k in ('google', 'google.colab'): sys.modules.pop(k, None)
for p in list(out.glob('*.jsonl')): p.unlink()
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:9000])
